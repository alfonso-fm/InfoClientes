﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LeerClientes.Infrastructure;
using LeerClientes.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace LeerClientes.Controllers
{
    public class ClienteController : Controller
    {
        private readonly AppDbContext _myDbContext;

        public ClienteController(Infrastructure.AppDbContext myDbContext)
        {
            _myDbContext = myDbContext;
        }


        [ActionName("Index")]
        public IActionResult LeerClientes()
        {
            List<Cliente> clientes = _myDbContext.InfoClientes
                      .FromSql($"uspConsultaInfoClientes")
                      .ToList();

            return View(clientes);
        }
    }
}


﻿using System;
using LeerClientes.Models;
using Microsoft.EntityFrameworkCore;

namespace LeerClientes.Infrastructure
{
	public class AppDbContext: DbContext
	{
        public AppDbContext(DbContextOptions options) : base(options)
        {
        }

        public AppDbContext()
        {
        }

        public virtual DbSet<Cliente> InfoClientes { get; set; }
    }
}


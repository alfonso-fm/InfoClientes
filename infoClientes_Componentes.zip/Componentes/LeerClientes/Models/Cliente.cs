﻿using System;
namespace LeerClientes.Models
{
	public class Cliente
	{
		public int ID { get; set; }
		public string ?Nombre { get; set; }
		public string ?TipoCliente { get; set; }
		public decimal ?LineaCredito { get; set; }
		public DateTime FechaIngreso { get; set; }
	}
}
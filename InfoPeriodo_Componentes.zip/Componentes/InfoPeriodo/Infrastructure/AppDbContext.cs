﻿using System;
using System.Collections.Generic;
using InfoPeriodo.Models;
using Microsoft.EntityFrameworkCore;

namespace InfoPeriodo.Infrastructure
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions options) : base(options)
        {
        }

        public AppDbContext()
        {
        }

        public virtual DbSet<Periodo> InfoPeriodo { get; set; }
    }
}


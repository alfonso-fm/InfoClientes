﻿using System;
namespace InfoPeriodo.Models
{
	public class Periodo
	{
		public int ID { get; set; }
		public DateTime Fecha { get; set; }
		public string ?Valor { get; set; }
	}
}


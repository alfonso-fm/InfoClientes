﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using InfoPeriodo.Models;
using InfoPeriodo.Infrastructure;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace InfoPeriodo.Controllers
{
    [Route("api/[controller]")]
    public class PeriodoController : Controller
    {

        private readonly AppDbContext _myDbContext;

        public PeriodoController(Infrastructure.AppDbContext myDbContext)
        {
            _myDbContext = myDbContext;
        }

        // GET: api/values
        [HttpGet]
        public List<Periodo> Get()
        {
            List<Periodo> periodos = _myDbContext.InfoPeriodo
                      .FromSql($"uspConsultainfoPeriodo")
                      .ToList();

            return periodos;
        }

        // POST api/values
        [HttpPost(Name = "Post")]
        public void RegistrarInfo(string valorInfo)
        {
            Periodo newPeriodo = new Periodo();
            newPeriodo.Fecha = DateTime.Now;
            newPeriodo.Valor = valorInfo;

            _myDbContext.InfoPeriodo.Add(newPeriodo);
            _myDbContext.SaveChanges();

        }

    }
}


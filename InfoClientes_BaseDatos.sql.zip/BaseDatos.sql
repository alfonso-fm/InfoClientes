CREATE TABLE InfoClientes( 
    ID           INT PRIMARY KEY IDENTITY NOT NULL,
    Nombre       VARCHAR(100) NOT NULL,
    TipoCliente  VARCHAR(3) NOT NULL, 
    LineaCredito DECIMAL NOT NULL,
    FechaIngreso DATETIME NOT NULL
)
GO
INSERT INTO InfoClientes VALUES('Jesus López', 'A', 20000, '01/07/2000');
INSERT INTO InfoClientes VALUES('Ramon Corona', 'A', 30000, '02/06/2001');
INSERT INTO InfoClientes VALUES('Gerardo Andres', 'B', 25000, '12/22/2007');
INSERT INTO InfoClientes VALUES('Ismael Molina', 'B', 27000, '11/18/2018');
INSERT INTO InfoClientes VALUES('Enrique Esteves', 'C', 39000, '10/11/2002');
INSERT INTO InfoClientes VALUES('Daniela Flores', 'C', 41000, '09/05/1999');
--DELETE FROM InfoClientes;
GO
CREATE PROCEDURE uspConsultaInfoClientes
AS 
BEGIN
    SELECT [ID]
         , [Nombre]
         , [TipoCliente]
         , [LineaCredito]
         , [FechaIngreso]
      FROM [dbo].[InfoClientes]
END
GO
EXECUTE uspConsultaInfoClientes
GO 

CREATE TABLE InfoPeriodo( 
    ID    INT PRIMARY KEY IDENTITY NOT NULL,
    Fecha DATETIME NOT NULL,
    Valor VARCHAR(100) NOT NULL,
)
GO
INSERT INTO InfoPeriodo VALUES(GETDATE(), 'Periodo 01');
INSERT INTO InfoPeriodo VALUES(GETDATE(), 'Periodo 02');
INSERT INTO InfoPeriodo VALUES(GETDATE(), 'Periodo 03');
INSERT INTO InfoPeriodo VALUES(GETDATE(), 'Periodo 04');
GO
CREATE PROCEDURE uspConsultainfoPeriodo
AS BEGIN
    SELECT [ID]
         , [Fecha]
         , [Valor]
      FROM [dbo].[InfoPeriodo]
END
EXECUTE uspConsultainfoPeriodo